/*
 * This class is used to create one transaction. It could be income or expense.
 */
public class Transaction {

    // How much money (positive for income, negative for expense)
    private double amount;

    // What the transaction was for, like "Food" or "Job" or whatever you decide
    private String category;

    // The date the transaction happened
    private String date;

    // This is the constructor. It runs when we make a new transaction.
    public Transaction(double amount, String category, String date) {
        this.amount = amount;
        this.category = category;
        this.date = date;
    }

    // This gives us the amount of the transaction
    public double getAmount() {
        return amount;
    }

    // This gives us the category, like "Food" or "Rent"
    public String getCategory() {
        return category;
    }

    // This gives us the date it happened
    public String getDate() {
        return date;
    }

    // This gives us all the info together in a sentence which is displayed in the transaction history
    public String getDetails() {
        return "Date: " + date + ", Category: " + category + ", Amount: $" + amount;
    }
}
