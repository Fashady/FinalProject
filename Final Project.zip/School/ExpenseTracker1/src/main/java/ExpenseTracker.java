import java.util.ArrayList;
import java.util.List;

/*
 * This class keeps track of all your transactions.
 * You can add income or expenses, and it calculates your total money.
 */

public class ExpenseTracker {

    // This is where we store all the transactions
    private List<Transaction> transactions;

    // When we create an ExpenseTracker, this starts an empty list
    public ExpenseTracker() {
        transactions = new ArrayList<>();
    }

    // This adds income (positive money) to the list
    public void addIncome(double amount, String category, String date) {
        transactions.add(new Transaction(amount, category, date));
    }

    // This adds expense (negative money) to the list
    public void addExpense(double amount, String category, String date) {
        transactions.add(new Transaction(-amount, category, date));
    }

    // This adds up all the transactions and gives us the current balance
    public double calculateBalance() {
        double balance = 0.0;
        for (Transaction t : transactions) {
            balance += t.getAmount(); // add each amount to the total
        }
        return balance;
    }

    // This gives us the full list of transactions
    public List<Transaction> getTransactions() {
        return transactions;
    }
}
