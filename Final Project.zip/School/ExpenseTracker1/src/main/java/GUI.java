import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.time.LocalDate;

/*
 * This is the GUI
 * It lets you enter income or expenses and shows your balance.
 */
public class GUI extends Application {

    // this is to store and manage all the transactions
    private ExpenseTracker tracker = new ExpenseTracker();

    // This big box shows all your transactions
    private TextArea transactionArea = new TextArea();

    // This shows your current money balance
    private Label balanceLabel = new Label("Balance: $0.0");

    // This is the main function that runs when the app starts
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Smart Expense Tracker");

        // --- INCOME SECTION ---

        // This is where you type the amount of income
        TextField incomeField = new TextField();
        incomeField.setPromptText("Income Amount");

        // This is where you type the category (like Job, Gift or whatever it is u want it to be)
        TextField incomeCategory = new TextField();
        incomeCategory.setPromptText("Category");

        // This is the button to add income
        Button addIncome = new Button("Add Income");

        // What happens when the Add Income button is clicked
        addIncome.setOnAction(e -> {
            double amount = Double.parseDouble(incomeField.getText());
            String category = incomeCategory.getText();
            tracker.addIncome(amount, category, LocalDate.now().toString());
            updateTransactions(); // refresh display (heard this is good to do from stack overflow but I wasnt 100% sure)
            incomeField.clear();
            incomeCategory.clear();
        });

        // --- EXPENSE SECTION ---

        // Where you type the amount of expense
        TextField expenseField = new TextField();
        expenseField.setPromptText("Expense Amount");

        // Where you type what the expense was for
        TextField expenseCategory = new TextField();
        expenseCategory.setPromptText("Category");

        // Button to add an expense
        Button addExpense = new Button("Add Expense");

        // What happens when you click Add Expense
        addExpense.setOnAction(e -> {
            double amount = Double.parseDouble(expenseField.getText());
            String category = expenseCategory.getText();
            tracker.addExpense(amount, category, LocalDate.now().toString());
            updateTransactions(); // refresh display (heard this is good to do from stack overflow but I wasnt 100% sure)
            expenseField.clear();
            expenseCategory.clear();
        });

        transactionArea.setEditable(false); // makes the box read-only so you cant just edit numbers and stuff

        // Layout: stack everything in one column with spacing (Watched Youtube to set this up)
        VBox layout = new VBox(10);
        layout.getChildren().addAll(
                new Label("Add Income"),
                incomeField, incomeCategory, addIncome,
                new Label("Add Expense"),
                expenseField, expenseCategory, addExpense,
                balanceLabel,
                new Label("Transactions:"),
                transactionArea
        );

        // Set up the window with size and content
        Scene scene = new Scene(layout, 400, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // This updates the screen to show transactions and balance 
    private void updateTransactions() {
        StringBuilder sb = new StringBuilder();
        for (Transaction t : tracker.getTransactions()) {
            sb.append(t.getDetails()).append("\n");
        }
        transactionArea.setText(sb.toString());
        balanceLabel.setText("Balance: $" + tracker.calculateBalance());
    }

    // This starts the JavaFX app
    public static void main(String[] args) {
        launch(args);
    }
}
